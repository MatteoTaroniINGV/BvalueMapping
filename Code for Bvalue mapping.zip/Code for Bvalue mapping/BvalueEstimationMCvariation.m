function [ B , N , Sigma ] = BvalueEstimationMCvariation( Data , MagnitudeColumn , MC_Column , Bin )

% INPUT :
% Data = catalogue of events
% MagnitudeColumn = the magnitude column of the catalogue
% MC_Column = the magnitude of completeness column of the catalogue
% Bin = bin of the magnitudes in the catalogue (usually for Mw is 0.01
%       and for ML is 0.1);

% OUTPUT :
% B = b-value Maximum Likelihood Estimation (of the Gutenberg-Richter law) 
%   taking into account the bin of the magnitudes 
% N = total number of events bigger or equal to MagnMin
% Sigma = b-value uncertainty


% subtract the corresponding magnitude of completeness to each magnitude
DataOk = Data( : , MagnitudeColumn ) - Data( : , MC_Column )  ;

% take the total number of events
N = length( DataOk ) ; 

% compute b-value using the equation from Taroni 2021 - GJI
B = ( ( N-1 ) / N ) /( log(10)*( mean( DataOk ) + Bin/2 ) ) ;  

% compute the b-value uncertainty
Sigma = B/sqrt(N) ; 