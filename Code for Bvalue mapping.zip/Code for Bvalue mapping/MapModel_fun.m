% Function to plot a map
%
% INPUT: 
%
% Cells: matrix with longitude, latitude and info to be mapped
% ColorbarInterval: interval for the colorbar of the map
%
%
% OUTPUT: 
%
% Map of the quantity stored in 'Cells'

function MapModel_fun( Cells , ColorbarInterval )

ColumnInfo = 3 ; % column with the info that must be mapped
ColumnLong = 1 ; % column of the longitudine
ColumnLat  = 2 ; % column of the latitudine

BinCell = 0.1 ; % spatial bin for the cells of the grid (degree)

Xmin = min(Cells(:,ColumnLong)) ;  %
Xmax = max(Cells(:,ColumnLong)) ;  % compute min and max for Long and Lat
                                   %  
Ymin = min(Cells(:,ColumnLat)) ;   %
Ymax = max(Cells(:,ColumnLat)) ;   %

% preallocation of the map matrix
Map = NaN( round( (Ymax-Ymin)*1/BinCell+1 ) , round( (Xmax-Xmin)*1/BinCell+1 ) );


% loop 'for' to add into the matrix 'Map' the info from 'Cells'
for i = 1 : size(Cells,1)
    
    % compute the line and column relative to the matrix 'Map'
    Line   = (Cells(i,ColumnLat ) - Ymin)*1/BinCell+1 ;
    Column = (Cells(i,ColumnLong) - Xmin)*1/BinCell+1 ; 

    % if there is an information on the i-th cell
    if isnan( Cells(i,ColumnInfo) ) == 0 
    
        % add the value to the matrix 'Map'
        % in case of multiple cells with the same long and lat, the final
        % information stored in 'Map' is the sum of all the information
        Map(round(Line),round(Column)) = nansum( [ Map(round(Line),round(Column)) , Cells(i,ColumnInfo) ] ) ;

    end
end


% create the map
pcolor( Xmin-BinCell/2 : BinCell : Xmax-BinCell/2 , ...
        Ymin-BinCell/2 : BinCell : Ymax-BinCell/2 , Map )
shading flat ;            % option for the 'pcolor' function                 
colorbar                  % add the colorbar
caxis( ColorbarInterval ) % set colorbar values of the map

% add the coast to the map
coast = load( 'CosteItalia.dat' ) ;    % change this file to plot a different coastline 
hold on                                %   
plot( coast(:,1) , coast(:,2) , 'k' )  %

