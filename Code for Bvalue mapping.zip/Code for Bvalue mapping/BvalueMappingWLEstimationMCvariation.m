% Function for the spatial weighted maximum likelihood estimation of the 
% Bvalue and its uncertainty (Sigma)
%
% INPUT
%
% Catalog:     seismic catalogue
% ColumnMagn:  column of the magnitude
% ColumnMC:    column of the completeness magnitude
% MagnBin:     binning of the magnitude
% LongLat:     matrix with long and lat of each cell of the spatial grid
% SigmaKernel: sigma of the spatial Gaussian kernel (in km)
%
%
% OUTPUT
%
% BvalueMap: map of the estimated Bvalue
% SigmaMap:  map of the estimated Sigma

function [ BvalueMap , SigmaMap ] = BvalueMappingWLEstimationMCvariation( Catalog , ColumnMagn , ColumnMC , MagnBin , LongLat , SigmaKernel )

% preallocation of Bvalue and Sigma matrix
BvalueMap = zeros( size( LongLat , 1 ) , 3 ); 
SigmaMap  = zeros( size( LongLat , 1 ) , 3 );

BvalueMap( : , 1 ) = LongLat( : , 1 ) ;    % assign longitude
BvalueMap( : , 2 ) = LongLat( : , 2 ) ;    % assign latitude
SigmaMap( : , 1 )  = LongLat( : , 1 ) ;    % assign longitude
SigmaMap( : , 2 )  = LongLat( : , 2 ) ;    % assign latitude


% computation for each cell in the grid of smoothed value
for i = 1 : size( BvalueMap , 1 )
    
        % compute the distance of each event in the catalogue from the
        % center of the (i-th,j-th) grid cell
        R = acos(sin(BvalueMap( i , 2 )*pi/180).* sin(Catalog( : , 2 )*pi/180) + cos(BvalueMap( i , 2 )*pi/180).*...
            cos(Catalog( : , 2 )*pi/180).* cos((Catalog( : , 1 ) - BvalueMap( i , 1 ))*pi/180))*6371 ;

        % compute the weights proportional to the Gaussian kernel
        W = 1/(2*pi*SigmaKernel^2)*exp((-R.^2)/(2*SigmaKernel^2)) ; 
        
        % compute the weighted MLE estimation for the B-value   
        BvalueMap( i , 3 ) = sum(W)/(sum(W.*(Catalog( : , ColumnMagn ) - Catalog( : , ColumnMC ) + MagnBin/2))*log(10)) ;
        
        % compute the standard deviation of the estimated B-value
        SigmaMap( i , 3 )  = BvalueMap( i , 3 )*( ( sum(W.^2) )^0.5 / sum(W) ) ;
        
end