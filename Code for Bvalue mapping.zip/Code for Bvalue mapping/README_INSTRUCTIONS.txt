Run on MATLAB "Script_for_Bvalue_and_Sigma_Mapping.m" to obtain the spatial wieghted likelihood estimation of the b-value and its uncertainty.
This script builds the Figure 2 of the paper Taroni et al. 2021 - SRL.
The input catalogue must be in ZMAP format, with the completeness magnitude associated to each event in the 11-th column.
The input catalogue must contain only events above the completeness magnitude.

